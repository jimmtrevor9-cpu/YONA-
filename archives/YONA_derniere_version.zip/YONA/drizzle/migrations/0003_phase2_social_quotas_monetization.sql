-- ============================================================
-- PHASE 2 — Fondations sociales, quotas et monétisation
-- Additif et non destructif : aucune table/colonne existante supprimée.
-- ============================================================

-- 1) Plan annuel (additif sur l'enum existant)
ALTER TYPE public.subscription_plan ADD VALUE IF NOT EXISTS 'premium_yearly';

-- 2) Nouveaux tarifs par défaut, en USD (cents). L'historique FCFA est conservé.
ALTER TABLE public.payments ALTER COLUMN currency SET DEFAULT 'USD';
ALTER TABLE public.conversation_unlocks ALTER COLUMN currency SET DEFAULT 'USD';
ALTER TABLE public.conversation_unlocks ALTER COLUMN amount SET DEFAULT 100;
ALTER TABLE public.subscriptions ALTER COLUMN currency SET DEFAULT 'USD';
ALTER TABLE public.subscriptions ALTER COLUMN amount SET DEFAULT 500;

-- ============================================================
-- 3) Quota de messages gratuits : 3 PAR PARTICIPANT et PAR CONVERSATION
-- La colonne conversations.free_messages_used est conservée (compatibilité Phase 1).
-- ============================================================
CREATE TABLE IF NOT EXISTS public.conversation_user_usage (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  conversation_id uuid NOT NULL REFERENCES public.conversations(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES public.users(id) ON DELETE CASCADE,
  free_messages_used smallint NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (conversation_id, user_id),
  CONSTRAINT conversation_user_usage_range CHECK (free_messages_used >= 0 AND free_messages_used <= 3)
);
-- Lecture seule côté client : l'incrémentation passe par une fonction serveur.
GRANT SELECT ON public.conversation_user_usage TO authenticated;
GRANT ALL ON public.conversation_user_usage TO service_role;
ALTER TABLE public.conversation_user_usage ENABLE ROW LEVEL SECURITY;
CREATE INDEX IF NOT EXISTS conversation_user_usage_conversation_idx ON public.conversation_user_usage (conversation_id);
CREATE INDEX IF NOT EXISTS conversation_user_usage_user_idx ON public.conversation_user_usage (user_id);
CREATE TRIGGER conversation_user_usage_updated_at BEFORE UPDATE ON public.conversation_user_usage
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

CREATE POLICY "cuu_select_own" ON public.conversation_user_usage FOR SELECT TO authenticated
  USING (user_id = auth.uid());
CREATE POLICY "cuu_select_admin" ON public.conversation_user_usage FOR SELECT TO authenticated
  USING (public.is_admin());

-- ============================================================
-- 4) Favoris
-- ============================================================
CREATE TABLE IF NOT EXISTS public.favorites (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES public.users(id) ON DELETE CASCADE,
  favorite_user_id uuid NOT NULL REFERENCES public.users(id) ON DELETE CASCADE,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (user_id, favorite_user_id),
  CONSTRAINT favorites_no_self CHECK (user_id <> favorite_user_id)
);
GRANT SELECT, INSERT, DELETE ON public.favorites TO authenticated;
GRANT ALL ON public.favorites TO service_role;
ALTER TABLE public.favorites ENABLE ROW LEVEL SECURITY;
CREATE INDEX IF NOT EXISTS favorites_user_idx ON public.favorites (user_id);
CREATE INDEX IF NOT EXISTS favorites_favorite_user_idx ON public.favorites (favorite_user_id);

CREATE POLICY "favorites_select_own" ON public.favorites FOR SELECT TO authenticated
  USING (user_id = auth.uid());
CREATE POLICY "favorites_select_admin" ON public.favorites FOR SELECT TO authenticated
  USING (public.is_admin());
CREATE POLICY "favorites_insert_own" ON public.favorites FOR INSERT TO authenticated
  WITH CHECK (user_id = auth.uid() AND user_id <> favorite_user_id
              AND NOT public.is_blocked_between(user_id, favorite_user_id));
CREATE POLICY "favorites_delete_own" ON public.favorites FOR DELETE TO authenticated
  USING (user_id = auth.uid());

-- « Qui m'a ajouté en favori » : réservé Premium, via fonction serveur.
CREATE OR REPLACE FUNCTION public.get_favorited_by()
RETURNS TABLE (user_id uuid, created_at timestamptz)
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT f.user_id, f.created_at
  FROM public.favorites f
  WHERE f.favorite_user_id = auth.uid()
    AND public.is_premium(auth.uid())
    AND NOT public.is_blocked_between(auth.uid(), f.user_id)
  ORDER BY f.created_at DESC
$$;

-- ============================================================
-- 5) Visites de profil
-- ============================================================
CREATE TABLE IF NOT EXISTS public.profile_visits (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  visitor_id uuid NOT NULL REFERENCES public.users(id) ON DELETE CASCADE,
  visited_user_id uuid NOT NULL REFERENCES public.users(id) ON DELETE CASCADE,
  visited_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT profile_visits_no_self CHECK (visitor_id <> visited_user_id)
);
-- Écriture uniquement via la fonction serveur record_profile_visit().
GRANT SELECT ON public.profile_visits TO authenticated;
GRANT ALL ON public.profile_visits TO service_role;
ALTER TABLE public.profile_visits ENABLE ROW LEVEL SECURITY;
CREATE INDEX IF NOT EXISTS profile_visits_visitor_idx ON public.profile_visits (visitor_id);
CREATE INDEX IF NOT EXISTS profile_visits_visited_idx ON public.profile_visits (visited_user_id);
CREATE INDEX IF NOT EXISTS profile_visits_visited_at_idx ON public.profile_visits (visited_at DESC);

CREATE POLICY "profile_visits_select_own_visits" ON public.profile_visits FOR SELECT TO authenticated
  USING (visitor_id = auth.uid());
CREATE POLICY "profile_visits_select_admin" ON public.profile_visits FOR SELECT TO authenticated
  USING (public.is_admin());

CREATE OR REPLACE FUNCTION public.record_profile_visit(_visited_user_id uuid)
RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE _visitor uuid := auth.uid();
BEGIN
  IF _visitor IS NULL OR _visited_user_id IS NULL OR _visitor = _visited_user_id THEN RETURN; END IF;
  IF public.is_blocked_between(_visitor, _visited_user_id) THEN RETURN; END IF;
  IF NOT EXISTS (SELECT 1 FROM public.users u WHERE u.id = _visited_user_id AND u.status = 'active') THEN RETURN; END IF;
  -- Anti-spam : une visite enregistrée au maximum par heure et par profil.
  IF EXISTS (
    SELECT 1 FROM public.profile_visits v
    WHERE v.visitor_id = _visitor AND v.visited_user_id = _visited_user_id
      AND v.visited_at > now() - interval '1 hour'
  ) THEN RETURN; END IF;
  INSERT INTO public.profile_visits (visitor_id, visited_user_id) VALUES (_visitor, _visited_user_id);
END; $$;

-- « Qui a visité mon profil » : réservé Premium.
CREATE OR REPLACE FUNCTION public.get_profile_visitors()
RETURNS TABLE (visitor_id uuid, visited_at timestamptz)
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT v.visitor_id, max(v.visited_at) AS visited_at
  FROM public.profile_visits v
  WHERE v.visited_user_id = auth.uid()
    AND public.is_premium(auth.uid())
    AND NOT public.is_blocked_between(auth.uid(), v.visitor_id)
  GROUP BY v.visitor_id
  ORDER BY max(v.visited_at) DESC
$$;

-- ============================================================
-- 6) Quota IA (Roi Salomon) : 3 questions/jour en Free, illimité en Premium
-- ============================================================
CREATE TABLE IF NOT EXISTS public.ai_usage (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES public.users(id) ON DELETE CASCADE,
  feature text NOT NULL DEFAULT 'roi_salomon',
  usage_date date NOT NULL DEFAULT current_date,
  usage_count integer NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (user_id, feature, usage_date),
  CONSTRAINT ai_usage_count_positive CHECK (usage_count >= 0)
);
-- Lecture seule côté client : l'incrémentation passe par une fonction serveur.
GRANT SELECT ON public.ai_usage TO authenticated;
GRANT ALL ON public.ai_usage TO service_role;
ALTER TABLE public.ai_usage ENABLE ROW LEVEL SECURITY;
CREATE INDEX IF NOT EXISTS ai_usage_user_idx ON public.ai_usage (user_id);
CREATE INDEX IF NOT EXISTS ai_usage_feature_date_idx ON public.ai_usage (feature, usage_date);
CREATE TRIGGER ai_usage_updated_at BEFORE UPDATE ON public.ai_usage
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

CREATE POLICY "ai_usage_select_own" ON public.ai_usage FOR SELECT TO authenticated
  USING (user_id = auth.uid());
CREATE POLICY "ai_usage_select_admin" ON public.ai_usage FOR SELECT TO authenticated
  USING (public.is_admin());

CREATE OR REPLACE FUNCTION public.get_ai_quota(_feature text DEFAULT 'roi_salomon')
RETURNS jsonb LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path = public AS $$
DECLARE _uid uuid := auth.uid(); _used integer := 0; _premium boolean;
BEGIN
  IF _uid IS NULL THEN RETURN jsonb_build_object('allowed', false, 'used', 0, 'limit', 3, 'unlimited', false); END IF;
  _premium := public.is_premium(_uid);
  SELECT COALESCE(usage_count, 0) INTO _used FROM public.ai_usage
    WHERE user_id = _uid AND feature = _feature AND usage_date = current_date;
  _used := COALESCE(_used, 0);
  RETURN jsonb_build_object(
    'allowed', _premium OR _used < 3,
    'used', _used,
    'limit', CASE WHEN _premium THEN NULL ELSE 3 END,
    'unlimited', _premium
  );
END; $$;

-- Consommation atomique : renvoie false si le quota gratuit est épuisé.
CREATE OR REPLACE FUNCTION public.consume_ai_quota(_feature text DEFAULT 'roi_salomon')
RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE _uid uuid := auth.uid(); _used integer; _premium boolean;
BEGIN
  IF _uid IS NULL THEN RETURN jsonb_build_object('allowed', false, 'reason', 'unauthenticated'); END IF;
  _premium := public.is_premium(_uid);

  INSERT INTO public.ai_usage (user_id, feature, usage_date, usage_count)
  VALUES (_uid, _feature, current_date, 0)
  ON CONFLICT (user_id, feature, usage_date) DO NOTHING;

  SELECT usage_count INTO _used FROM public.ai_usage
    WHERE user_id = _uid AND feature = _feature AND usage_date = current_date FOR UPDATE;

  IF NOT _premium AND _used >= 3 THEN
    RETURN jsonb_build_object('allowed', false, 'reason', 'quota_exceeded', 'used', _used, 'limit', 3);
  END IF;

  UPDATE public.ai_usage SET usage_count = usage_count + 1
    WHERE user_id = _uid AND feature = _feature AND usage_date = current_date
    RETURNING usage_count INTO _used;

  RETURN jsonb_build_object('allowed', true, 'used', _used,
    'limit', CASE WHEN _premium THEN NULL ELSE 3 END, 'unlimited', _premium);
END; $$;

-- ============================================================
-- 7) Déblocage de conversation : actif pour LES DEUX participants
-- ============================================================
CREATE OR REPLACE FUNCTION public.has_active_conversation_unlock(_conversation_id uuid)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.conversation_unlocks u
    WHERE u.conversation_id = _conversation_id
      AND u.status = 'active'
      AND u.starts_at IS NOT NULL AND u.starts_at <= now()
      AND u.expires_at IS NOT NULL AND u.expires_at > now()
  )
$$;

-- ============================================================
-- 8) Consommation d'un message gratuit (source de vérité serveur)
-- ============================================================
CREATE OR REPLACE FUNCTION public.get_conversation_quota(_conversation_id uuid)
RETURNS jsonb LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path = public AS $$
DECLARE _uid uuid := auth.uid(); _used smallint := 0; _premium boolean; _unlocked boolean;
BEGIN
  IF _uid IS NULL OR NOT public.is_conversation_participant(_conversation_id, _uid) THEN
    RETURN jsonb_build_object('allowed', false, 'reason', 'not_participant');
  END IF;
  _premium := public.is_premium(_uid);
  _unlocked := public.has_active_conversation_unlock(_conversation_id);
  SELECT COALESCE(free_messages_used, 0) INTO _used FROM public.conversation_user_usage
    WHERE conversation_id = _conversation_id AND user_id = _uid;
  _used := COALESCE(_used, 0);
  RETURN jsonb_build_object(
    'allowed', _premium OR _unlocked OR _used < 3,
    'used', _used,
    'limit', CASE WHEN _premium OR _unlocked THEN NULL ELSE 3 END,
    'premium', _premium,
    'unlocked', _unlocked
  );
END; $$;

CREATE OR REPLACE FUNCTION public.consume_free_message(_conversation_id uuid)
RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE _uid uuid := auth.uid(); _used smallint; _premium boolean; _unlocked boolean; _status public.conversation_status;
BEGIN
  IF _uid IS NULL THEN RETURN jsonb_build_object('allowed', false, 'reason', 'unauthenticated'); END IF;
  IF NOT public.is_conversation_participant(_conversation_id, _uid) THEN
    RETURN jsonb_build_object('allowed', false, 'reason', 'not_participant');
  END IF;

  SELECT status INTO _status FROM public.conversations WHERE id = _conversation_id;
  IF _status = 'closed' THEN RETURN jsonb_build_object('allowed', false, 'reason', 'conversation_closed'); END IF;

  _premium := public.is_premium(_uid);
  _unlocked := public.has_active_conversation_unlock(_conversation_id);
  IF _premium OR _unlocked THEN
    RETURN jsonb_build_object('allowed', true, 'unlimited', true, 'premium', _premium, 'unlocked', _unlocked);
  END IF;

  INSERT INTO public.conversation_user_usage (conversation_id, user_id, free_messages_used)
  VALUES (_conversation_id, _uid, 0)
  ON CONFLICT (conversation_id, user_id) DO NOTHING;

  SELECT free_messages_used INTO _used FROM public.conversation_user_usage
    WHERE conversation_id = _conversation_id AND user_id = _uid FOR UPDATE;

  IF _used >= 3 THEN
    RETURN jsonb_build_object('allowed', false, 'reason', 'free_limit_reached', 'used', _used, 'limit', 3);
  END IF;

  UPDATE public.conversation_user_usage SET free_messages_used = free_messages_used + 1
    WHERE conversation_id = _conversation_id AND user_id = _uid
    RETURNING free_messages_used INTO _used;

  -- Compatibilité Phase 1 : compteur global conservé et maintenu.
  UPDATE public.conversations SET free_messages_used = LEAST(free_messages_used + 1, 32767)
    WHERE id = _conversation_id;

  RETURN jsonb_build_object('allowed', true, 'used', _used, 'limit', 3, 'unlimited', false);
END; $$;

-- ============================================================
-- 9) Limite de photos : 3 en Free, 10 en Premium (contrôle serveur)
-- ============================================================
CREATE OR REPLACE FUNCTION public.enforce_photo_limit()
RETURNS TRIGGER LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE _count integer; _max integer;
BEGIN
  SELECT count(*) INTO _count FROM public.photos WHERE user_id = NEW.user_id;
  _max := CASE WHEN public.is_premium(NEW.user_id) THEN 10 ELSE 3 END;
  IF _count >= _max THEN
    RAISE EXCEPTION 'photo_limit_reached: % photos maximum', _max
      USING ERRCODE = 'check_violation';
  END IF;
  RETURN NEW;
END; $$;
CREATE TRIGGER photos_enforce_limit BEFORE INSERT ON public.photos
  FOR EACH ROW EXECUTE FUNCTION public.enforce_photo_limit();

-- ============================================================
-- 10) Droits d'exécution des fonctions (cohérent avec la Phase 1)
-- ============================================================
REVOKE EXECUTE ON FUNCTION public.enforce_photo_limit() FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.get_favorited_by() FROM PUBLIC, anon;
REVOKE EXECUTE ON FUNCTION public.get_profile_visitors() FROM PUBLIC, anon;
REVOKE EXECUTE ON FUNCTION public.record_profile_visit(uuid) FROM PUBLIC, anon;
REVOKE EXECUTE ON FUNCTION public.get_ai_quota(text) FROM PUBLIC, anon;
REVOKE EXECUTE ON FUNCTION public.consume_ai_quota(text) FROM PUBLIC, anon;
REVOKE EXECUTE ON FUNCTION public.has_active_conversation_unlock(uuid) FROM PUBLIC, anon;
REVOKE EXECUTE ON FUNCTION public.get_conversation_quota(uuid) FROM PUBLIC, anon;
REVOKE EXECUTE ON FUNCTION public.consume_free_message(uuid) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION
  public.get_favorited_by(),
  public.get_profile_visitors(),
  public.record_profile_visit(uuid),
  public.get_ai_quota(text),
  public.consume_ai_quota(text),
  public.has_active_conversation_unlock(uuid),
  public.get_conversation_quota(uuid),
  public.consume_free_message(uuid)
TO authenticated, service_role;